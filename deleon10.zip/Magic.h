#ifndef MAGIC_H_
#define MAGIC_H_

#include "Displayable.h"
#include <memory>

class Magic : public Displayable {
	Magic();
};

#endif
#include "Magic.h"
Magic::Magic() {
	//std::cout << "Magic constructor" << std::endl;
}
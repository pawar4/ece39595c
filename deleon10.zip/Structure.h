#ifndef STRUCTURE_H_
#define STRUCTURE_H_

#include <iostream>

#include "Displayable.h"
#include <memory>

class Structure : public Displayable {
public:
    Structure();
};
#endif
#include <iostream>
#include "Structure.h"

Structure::Structure() {
    //std::cout << "Structure constructor" << std::endl;
}